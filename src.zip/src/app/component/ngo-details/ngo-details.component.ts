import { Component, OnInit } from '@angular/core';
 
import { ActivatedRoute, Router } from '@angular/router';
import { NgoService } from 'src/app/Services/ngo.service';
import { ngo } from '../ngo/ngo';

@Component({
  selector: 'app-ngo-details',
  templateUrl: './ngo-details.component.html',
  styleUrls: ['./ngo-details.component.css']
})
export class NgoDetailsComponent implements OnInit {
  ngoId:any;
  //sub:any;
  // ngo:any;
  // p:any;
 // id=100;
  constructor(private activatedroute:ActivatedRoute,
              private router:Router,
              private ngoService:NgoService
             ) { }

  ngOnInit(): void {
      this.activatedroute.paramMap.subscribe(data => { 
      console.log("Ngo id passed is :"+ data.get('ngoId'));
      this.ngoId = data.get('ngoId'); 
      
      // console.log("Ngo id passing to training is :"+ this.ngoId);
      // this.router.navigate(['/trainings',this.ngoId, this.ngoId]);

    // this.sub=this.activatedroute.paramMap.subscribe(params => { 
    //   console.log(params);
    //    this.ngoId = params.get('ngoId'); 
    //    let ngo=this.ngoService.getNgoList();
    //    this.ngo=ngo.find(p => p.ngoId==this.ngoId);    
  });
  }
 
  // route() {
  //   this.router.navigate(['/trainings'], {queryParams: {ngoId: this.ngoId}});
  // }
  // route() {
  //   console.log("Ngo id passing to traing with route is :"+ this.ngoId);
  //   this.router.navigate(['/trainings',this.ngoId, this.ngoId]);
  // }
  

}
