import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgoService } from 'src/app/Services/ngo.service';
import { ngo } from './ngo';

@Component({
  selector: 'app-ngo',
  templateUrl: './ngo.component.html',
  styleUrls: ['./ngo.component.css']
})
export class NgoComponent implements OnInit {

  ngoList:ngo[]=[];
  constructor(private httpServ: NgoService) { }

  ngOnInit(): void {
    this.getNgoList();
  }

   public getNgoList()
   {
    return this.httpServ
    .getNgoList()
    .subscribe((response: ngo[]) =>{
                            console.log("getting response  ")
                            this.ngoList=response;
                            console.log(this.ngoList);
                              }
              ) 
   }

}
