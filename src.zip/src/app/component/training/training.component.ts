import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';

@Component({
  selector: 'app-training',
  templateUrl: './training.component.html',
  styleUrls: ['./training.component.css']
})
export class TrainingComponent implements OnInit {
  ngoId:any;
  
  // constructor(
  //   private activatedroute: ActivatedRoute
  // ) {
  //   // this.ngoId = this.activatedroute.queryParams.subscribe(data => {
  //   //   console.log("Ngo id in Training component:"+this.ngoId);
  //   this.activatedroute.params.subscribe(data => {
  //     console.log("Ngo id in Training component:"+data);
  //   })
  // }
  constructor(private activatedroute:ActivatedRoute,
    private router:Router,
   ) { }

  ngOnInit(): void {
    this.activatedroute.paramMap.subscribe(data => { 
      console.log("Ngo id in training is :"+ data.get('ngoId'));
      this.ngoId = data.get('ngoId'); 
  });
  
  
}
}
