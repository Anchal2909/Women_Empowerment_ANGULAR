
export class register
{
    // constructor(public techId:number, public techName:string) {
    // }
}